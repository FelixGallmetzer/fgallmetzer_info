package brueche;

public class BruchException extends Exception
{
	public BruchException(String fehler) {
		super(fehler);
	}
}
