package RatenRechner;

public class RatenRechnerException extends Exception
{
	public RatenRechnerException(String s) {
		super(s);
	}
}
