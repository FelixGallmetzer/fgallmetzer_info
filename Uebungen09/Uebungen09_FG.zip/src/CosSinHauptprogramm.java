
public class CosSinHauptprogramm
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CosSinFenster f = new CosSinFenster();

	}

}
