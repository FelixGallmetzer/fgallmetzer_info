
public class KreisHauptprogramm
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		KreisGUI f = new KreisGUI();
	}

}
